## ----global_options, include=FALSE--------------------------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(dpi = 100, echo= TRUE, warning=FALSE, message=FALSE, fig.align = 'center',
                      fig.show=TRUE, fig.keep = 'all')


## -----------------------------------------------------------------------------------------------------------
library(mixOmics) # import the mixOmics library

set.seed(5249) # for reproducibility, remove for normal use


## -----------------------------------------------------------------------------------------------------------
data("Koren.16S") # extract the microbial data
X <- Koren.16S$data.raw # set the raw OTU data as the predictor dataframe
Y <- Koren.16S$bodysite # set the bodysite classification as the response vector

dim(X) # check dimensions of predictors
summary(Y) # check distribution of response


## ---- fig.cap = "FIGURE 1: Bar plot of the proportion of explained variance by each principal component yielded from a PCA."----
koren.pca = pca(X, ncomp = 10, logratio = 'CLR') # undergo PCA with 10 components

plot(koren.pca) # plot explained variance


## ---- fig.cap = "FIGURE 2: Sample plots from PCA performed on the Koren OTU data. Samples are projected into the space spanned by the first two components."----
koren.pca = pca(X, ncomp = 2, logratio = 'CLR') # undergo PCA with 2 components

plotIndiv(koren.pca, # plot samples projected onto PCs
          ind.names = FALSE, # not showing sample names
          group = Y, # color according to Y
          legend = TRUE,
          title = 'Koren OTUs, PCA Comps 1&2')


## -----------------------------------------------------------------------------------------------------------
basic.koren.plsda = plsda(X, Y, logratio = 'CLR', 
                          ncomp = nlevels(Y))


## ---- fig.cap = "FIGURE 3: Classification error rates for the basic sPLS-DA model on the Koren OTU data. Includes the standard and balanced error rates across all three distance metrics."----
basic.koren.perf.plsda = perf(basic.koren.plsda,  # assess the performance of the sPLS-DA model
                              validation = 'Mfold', 
                              folds = 5, nrepeat = 10, # using repeated CV
                              progressBar = FALSE)

optimal.ncomp <- basic.koren.perf.plsda$choice.ncomp["BER", "max.dist"] # extract the optimal component number

plot(basic.koren.perf.plsda, overlay = 'measure', sd=TRUE) # plot this tuning


## ---- fig.cap = "FIGURE 4: Tuning keepX for the sPLS-DA performed on the Koren OTU data. Each coloured line represents the balanced error rate (y-axis) per component across all tested keepX values (x-axis) with the standard deviation based on the repeated cross-validation folds."----
grid.keepX = c(seq(5,150, 5))

koren.tune.splsda = tune.splsda(X, Y,
                          ncomp = optimal.ncomp, # use optimal component number
                          logratio = 'CLR', # transform data to euclidean space
                          test.keepX = grid.keepX,
                          validation = c('Mfold'),
                          folds = 5, nrepeat = 10, # use repeated CV
                          dist = 'max.dist', # maximum distance as metric
                          progressBar = FALSE)

optimal.keepX = koren.tune.splsda$choice.keepX[1:2] # extract the optimal component number
optimal.ncomp = koren.tune.splsda$choice.ncomp$ncomp # extract the optimal feature count per component

plot(koren.tune.splsda) # plot this tuning


## -----------------------------------------------------------------------------------------------------------
koren.splsda = splsda(X,  Y, logratio= "CLR", # form final sPLS-DA model
                      ncomp = optimal.ncomp, 
                      keepX = optimal.keepX)


## ---- fig.cap = "FIGURE 5: Sample plots from sPLS-DA performed on the Koren OTU data. Samples are projected into the space spanned by the first two components."----
plotIndiv(koren.splsda,
          comp = c(1,2),
          ind.names = FALSE,
          ellipse = TRUE, # include confidence ellipses
          legend = TRUE,
          legend.title = "Bodysite",
          title = 'Koren OTUs, sPLS-DA Comps 1&2')


## ---- eval = FALSE------------------------------------------------------------------------------------------
## cim(koren.splsda,
##     comp = c(1,2),
##     row.sideColors = color.mixo(Y), # colour rows based on bodysite
##     legend = list(legend = c(levels(Y))),
##     title = 'Clustered Image Map of Koren Bodysite data')


## ---- fig.cap = "FIGURE 6: Clsutered Image Map of the Koren OTU data after sPLS-DA modelling. Only the keepX selected feature for components 1 and 2 are shown, with the colour of each cell depicting the raw OTU value after a CLR transformation.", echo = FALSE----
knitr::include_graphics("Figures/Koren CIM.png")


## ---- fig.cap = "FIGURE 7: Correlation circle plot representing the OTUs selected by sPLS-DA performed on the Koren OTU data. Only the OTUs selected by sPLS-DA are shown in components 1 and 2. Cutoff of 0.7 used"----
plotVar(koren.splsda,
        comp = c(1,2),
        cutoff = 0.7, rad.in = 0.7,
        title = 'Koren OTUs, Correlation Circle Plot Comps 1&2')


## ---- eval = FALSE------------------------------------------------------------------------------------------
## network(koren.splsda,
##         cutoff = 0.5,
##         color.node = c("orange","lightblue"))


## ---- fig.cap = "FIGURE 8: Relevance Network graph of the Koren OTUs selected by sPLS-DA on this dataset.", echo = FALSE----
knitr::include_graphics("Figures/Koren Network.png")


## -----------------------------------------------------------------------------------------------------------
set.seed(5249)  # for reproducible results for this code, remove for your own code

koren.perf.splsda = perf(koren.splsda, validation = 'Mfold', # evaluate classification
                         folds = 5, nrepeat = 10, # use repeated CV
                         progressBar = FALSE, dist = 'max.dist') # use maximum distance as metric

koren.perf.splsda$error.rate


## ---- fig.show = "hold", out.width = "49%", fig.cap = "FIGURE 9: The loading values of the top 20 contributing OTUs to the first (a) and second (b) components of a sPLS-DA undergone on the Koren OTU dataset. Each bar is coloured based on which bodysite had the maximum, mean value of that OTU."----
plotLoadings(koren.splsda, comp = 1, 
             method = 'mean', contrib = 'max',  
             size.name = 0.8, legend = FALSE,  
             ndisplay = 20,
             title = "(a) Loadings of first component")

plotLoadings(koren.splsda, comp = 2, 
             method = 'mean', contrib = 'max',   
             size.name = 0.7,
             ndisplay = 20,
             title = "(b) Loadings of second comp.")


## -----------------------------------------------------------------------------------------------------------
selected.OTU.comp1 = selectVar(koren.splsda, comp = 1)$name # determine which OTUs were selected

koren.perf.splsda$features$stable[[1]][selected.OTU.comp1] # display the stability values of these OTUs

