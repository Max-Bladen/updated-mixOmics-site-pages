## ----global_options, include=FALSE--------------------------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(dpi = 100, echo= TRUE, warning=FALSE, message=FALSE, fig.align = 'center',
                      fig.show=TRUE, fig.keep = 'all')


## -----------------------------------------------------------------------------------------------------------
library(mixOmics) # import the mixOmics library
library(mixKernel) # import the mixKernel library


## -----------------------------------------------------------------------------------------------------------
phychem.kernel = compute.kernel(TARAoceans$phychem, kernel.func = "linear")
pro.phylo.kernel = compute.kernel(TARAoceans$pro.phylo, kernel.func = "abundance")
pro.NOGs.kernel = compute.kernel(TARAoceans$pro.NOGs, kernel.func = "abundance")


## ---- fig.cap = "FIGURE 1: Simple Clustered Image Map depicting the correlation structure between the three inputted datasets. The colour uses the legend (on the right) to denote the correlation strength."----
cim.kernel(phychem = phychem.kernel,
           pro.phylo = pro.phylo.kernel,
           pro.NOGs = pro.NOGs.kernel, 
           method = "square")


## -----------------------------------------------------------------------------------------------------------
meta.kernel = combine.kernels(phychem = phychem.kernel,
                               pro.phylo = pro.phylo.kernel,
                               pro.NOGs = pro.NOGs.kernel, 
                               method = "full-UMKL")


## -----------------------------------------------------------------------------------------------------------
kernel.pca.result = kernel.pca(meta.kernel, ncomp = 10)


## ---- fig.cap = "FIGURE 2: Projection of the samples onto the first two Principal Components of a KPCA run over the meta kernel of the three inputted dataframes."----
all.depths = levels(factor(TARAoceans$sample$depth))
depth.pch = c(20, 17, 4, 3)[match(TARAoceans$sample$depth, all.depths)]
plotIndiv(kernel.pca.result,
          comp = c(1, 2),
          ind.names = FALSE,
          legend = TRUE,
          group = as.vector(TARAoceans$sample$ocean),
          col.per.group = c("#f99943", "#44a7c4", "#05b052", "#2f6395", 
                            "#bb5352", "#87c242", "#07080a", "#92bbdb"),
          pch = depth.pch,
          pch.levels = TARAoceans$sample$depth,
          legend.title = "Ocean / Sea",
          title = "Projection of TARA Oceans stations",
          size.title = 10,
          legend.title.pch = "Depth")


## ---- fig.cap = "FIGURE 3: Explained variance of each principal component of a KPCA run over the meta kernel of the three inputted dataframes."----
plot(kernel.pca.result)


## -----------------------------------------------------------------------------------------------------------
# here we set a seed for reproducible results with this tutorial
set.seed(17051753)
kernel.pca.result = kernel.pca.permute(kernel.pca.result, ncomp = 1,
                                        phychem = colnames(TARAoceans$phychem),
                                        pro.phylo = TARAoceans$taxonomy[ ,"Phylum"],
                                        pro.NOGs = TARAoceans$GO)


## ---- fig.cap = "FIGURE 4: Importance of the original features to each kernel. The height of each column indicates that features contribution to the first component of the corresponding kernel."----
plotVar.kernel.pca(kernel.pca.result, ndisplay = 10, ncol = 3)


## ---- fig.cap = "FIGURE 5: Projection of the samples onto the first two Principal Components of a KPCA run over the meta kernel of the three inputted dataframes."----
selected = which(TARAoceans$taxonomy[ ,"Phylum"] == "Proteobacteria") # subset features to those which belong to this Phylum

# for each feature determine the proportion of samples which belong to the Proteobacteria phylum
proteobacteria.per.sample = apply(TARAoceans$pro.phylo[ ,selected], 1, sum) /
                            apply(TARAoceans$pro.phylo, 1, sum)

# set colour
colfunc = colorRampPalette(c("royalblue", "red"))
col.proteo = colfunc(length(proteobacteria.per.sample))
col.proteo = col.proteo[rank(proteobacteria.per.sample, ties = "first")]

plotIndiv(kernel.pca.result,
          comp = c(1, 2),
          ind.names = FALSE,
          legend = FALSE,
          group = c(1:139),
          col = col.proteo,
          pch = depth.pch,
          pch.levels = TARAoceans$sample$depth,
          legend.title = "Ocean / Sea",
          title = "Representation of Proteobacteria abundance",
          legend.title.pch = "Depth")


## ---- fig.cap = "FIGURE 6: Projection of the samples onto the first two Principal Components of a KPCA run over the meta kernel of the three inputted dataframes."----
col.temp = colfunc(length(TARAoceans$phychem[ ,4]))
col.temp = col.temp[rank(TARAoceans$phychem[ ,4], ties = "first")]

plotIndiv(kernel.pca.result,
          comp = c(1, 2),
          ind.names = FALSE,
          legend = FALSE,
          group = c(1:139),
          col = col.temp,
          pch = depth.pch,
          pch.levels = TARAoceans$sample$depth,
          legend.title = "Ocean / Sea",
          title = "Representation of mean temperature",
          legend.title.pch = "Depth")

