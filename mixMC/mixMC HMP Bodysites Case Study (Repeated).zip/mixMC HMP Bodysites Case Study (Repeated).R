## ----global_options, include=FALSE--------------------------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(dpi = 100, echo= TRUE, warning=FALSE, message=FALSE,
                      fig.show=TRUE, fig.keep = 'all')


## -----------------------------------------------------------------------------------------------------------
library(mixOmics) # import the mixOmics library

set.seed(5249) # for reproducibility, remove for normal use


## -----------------------------------------------------------------------------------------------------------
data("diverse.16S") # extract the microbial data
X <- diverse.16S$data.raw # set the raw OTU data as the predictor dataframe
Y <- diverse.16S$bodysite # set the bodysite classification as the response vector
sample <- diverse.16S$sample

dim(X) # check dimensions of predictors
summary(Y) # check distribution of response


## ---- fig.align = "center"----------------------------------------------------------------------------------
diverse.pca = pca(X, ncomp = 10, logratio = 'CLR', multilevel = sample) # undergo PCA with 10 components and account for repeated measures

plot(diverse.pca) # plot explained variance


## ---- out.width = "49%", fig.show = "hold"------------------------------------------------------------------
diverse.pca.nonRM = pca(X, ncomp = 2, logratio = 'CLR') # undergo PCA with 2 components
diverse.pca.RM = pca(X, ncomp = 2, logratio = 'CLR', multilevel = sample) # undergo PCA with 2 components and account for repeated measures

plotIndiv(diverse.pca.nonRM, # plot samples projected onto PCs
          ind.names = FALSE, # not showing sample names
          group = Y, # color according to Y,
          title = '(a) Diverse.16S PCA Comps 1&2 (nonRM)')

plotIndiv(diverse.pca.RM, # plot samples projected onto PCs
          ind.names = FALSE, # not showing sample names
          group = Y, # color according to Y
          legend = TRUE,
          title = '(b) Diverse.16S PCA Comps 1&2 (RM)')


## -----------------------------------------------------------------------------------------------------------
basic.diverse.plsda = plsda(X, Y, logratio = 'CLR', 
                          ncomp = nlevels(Y),
                          multilevel = sample)


## ---- fig.align = "center"----------------------------------------------------------------------------------
basic.diverse.perf.plsda = perf(basic.diverse.plsda,  # assess the performance of the sPLS-DA model
                              validation = 'Mfold', 
                              folds = 5, nrepeat = 10, # using repeated CV
                              progressBar = FALSE)

optimal.ncomp <- basic.diverse.perf.plsda$choice.ncomp["BER", "max.dist"] # extract the optimal component number

plot(basic.diverse.perf.plsda, overlay = 'measure', sd=TRUE) # plot this tuning


## ---- fig.align = "center"----------------------------------------------------------------------------------
set.seed(5249)

grid.keepX = c(seq(5,150, 5))

diverse.tune.splsda = tune.splsda(X, Y,
                          ncomp = 3, # use optimal component number
                          logratio = 'CLR', # transform data to euclidean space
                          multilevel = sample,
                          test.keepX = grid.keepX,
                          validation = c('Mfold'),
                          folds = 5, nrepeat = 10, # use repeated CV
                          dist = 'max.dist', # maximum distance as metric
                          progressBar = FALSE)

optimal.ncomp = diverse.tune.splsda$choice.ncomp$ncomp # extract the optimal component number
optimal.keepX = diverse.tune.splsda$choice.keepX[1:optimal.ncomp] # extract the optimal feature count per component

plot(diverse.tune.splsda) # plot this tuning


## -----------------------------------------------------------------------------------------------------------
diverse.splsda = splsda(X,  Y, logratio= "CLR", # form final sPLS-DA model
                      multilevel = sample,
                      ncomp = optimal.ncomp,
                      keepX = optimal.keepX)


## ---- fig.align = "center"----------------------------------------------------------------------------------
plotIndiv(diverse.splsda,
          comp = c(1,2),
          ind.names = FALSE,
          ellipse = TRUE, # include confidence ellipses
          legend = TRUE,
          legend.title = "Bodysite",
          title = 'Diverse OTUs, sPLS-DA Comps 1&2')


## ---- eval = FALSE------------------------------------------------------------------------------------------
## cim(diverse.splsda,
##     comp = c(1,2),
##     row.sideColors = color.mixo(Y), # colour rows based on bodysite
##     legend = list(legend = c(levels(Y))),
##     title = 'Clustered Image Map of Diverse Bodysite data')


## ---- fig.align = "center"----------------------------------------------------------------------------------
plotVar(diverse.splsda,
        comp = c(1,2),
        cutoff = 0.5, rad.in = 0.5,
        var.names = FALSE, pch = 19,
        title = 'Diverse OTUs, Correlation Circle Plot Comps 1&2')


## -----------------------------------------------------------------------------------------------------------
set.seed(5249)  # for reproducible results for this code, remove for your own code

diverse.perf.splsda = perf(diverse.splsda, validation = 'Mfold', # evaluate classification
                         folds = 5, nrepeat = 10, # use repeated CV
                         progressBar = FALSE, dist = 'max.dist') # use maximum distance as metric

diverse.perf.splsda$error.rate


## ---- fig.show = "hold", out.width = "49%"------------------------------------------------------------------
plotLoadings(diverse.splsda, comp = 1, 
             method = 'mean', contrib = 'max',  
             size.name = 0.8, legend = FALSE,  
             ndisplay = 20,
             title = "(a) Loadings of comp. 1")

plotLoadings(diverse.splsda, comp = 2, 
             method = 'mean', contrib = 'max',   
             size.name = 0.7,
             ndisplay = 20,
             title = "(b) Loadings of comp. 2")


## -----------------------------------------------------------------------------------------------------------
selected.OTU.comp1 = selectVar(diverse.splsda, comp = 1)$name # determine which OTUs were selected

diverse.perf.splsda$features$stable[[1]][selected.OTU.comp1] # display the stability values of these OTUs

