## ----global_options, include=FALSE--------------------------------------------------------------------------
library(knitr)
knitr::opts_chunk$set(dpi = 100, echo= TRUE, warning=FALSE, message=FALSE, fig.align = 'center',
                      fig.show=TRUE, fig.keep = 'all')


## -----------------------------------------------------------------------------------------------------------
library(mixOmics) # import the mixOmics library

set.seed(5249) # for reproducibility, remove for normal use


## -----------------------------------------------------------------------------------------------------------
data("Koren.16S") # extract the microbial data

data.offset <- Koren.16S$data.raw


## ---- eval = FALSE------------------------------------------------------------------------------------------
## data.offset <- data.offset + 1 # apply offset


## -----------------------------------------------------------------------------------------------------------
sum(which(data.offset == 0)) # how many zeroes are there after offset


## -----------------------------------------------------------------------------------------------------------
low.count.removal <- function(
                        data, # OTU count data frame of size n (sample) x p (OTU)
                        percent=0.01 # cutoff chosen
                        ) 
  {
    keep.otu = which(colSums(data)*100/(sum(colSums(data))) > percent)
    data.filter = data[,keep.otu]
    return(list(data.filter = data.filter, keep.otu = keep.otu))
}


## -----------------------------------------------------------------------------------------------------------
dim(data.offset) # check samples are in rows


## -----------------------------------------------------------------------------------------------------------
# call the function then apply on the offset data
result.filter <- low.count.removal(data.offset, percent=0.01)
data.filter <- result.filter$data.filter
# check the number of variables kept after filtering
# in this particular case we had already filtered the data so no was change made, but from now on we will work with 'data.filter'
length(result.filter$keep.otu) 


## ---- fig.cap = "FIGURE 1: Barplot of the library size of each sample from the Koren OTU data."-------------
lib.size <- apply(data.filter, 1, sum) # determine total count for each sample
barplot(lib.size) # and plot as bar plot


## ---- eval = FALSE------------------------------------------------------------------------------------------
## maximum.lib.size <- 15000
## 
## data.filter <- data.filter[-which(lib.size > maximum.lib.size),]


## ---- fig.cap = "FIGURE 2: Samples of Koren OTU data projected onto components after a CLR transformation (done within the `pca()` function)."----
pca.result <- pca(data.filter, logratio = 'CLR') # undergo PCA on CLR transformed data
plotIndiv(pca.result,  # plot samples
          group = Koren.16S$bodysite, 
          title = 'Koren, PCA Comps 1&2',
          legend = TRUE)


## -----------------------------------------------------------------------------------------------------------
data.clr <- logratio.transfo(as.matrix(data.filter), logratio = 'CLR', offset = 0) # undergo CLR transformation


## ---- fig.cap = "FIGURE 3: Samples of Koren OTU data projected onto components after a CLR transformation (done prior to calling the `pca()` function)."----
pca.clr <- pca(data.clr) # undergo PCA on CLR transformed data
plotIndiv(pca.clr,  # plot samples
          group = Koren.16S$bodysite, 
          title = 'Koren, PCA Comps 1&2',
          legend = TRUE)


## -----------------------------------------------------------------------------------------------------------
library(phyloseq)
data(GlobalPatterns) # load the data from the phyloseq package

taxo <- tax_table(GlobalPatterns) # extraction of the taxonomy

meta.data <- GlobalPatterns@sam_data # extraction of the metadata

# extract OTU table from phyloseq object
data.raw <- t(otu_table(GlobalPatterns)) # samples should be in row and variables in column


## -----------------------------------------------------------------------------------------------------------
# STEP 1: OFFSET
data.offset <- data.raw+1
sum(which(data.offset == 0)) # check how many zeroes there are


## -----------------------------------------------------------------------------------------------------------
dim(data.offset) # check dimensions


## -----------------------------------------------------------------------------------------------------------
# STEP 2: PRE-FILTER
result.filter <- low.count.removal(data.offset, percent=0.01) # remove low count OTUs
data.filter <- result.filter$data.filter
length(result.filter$keep.otu) # check how many OTUs remain


## ---- eval = FALSE------------------------------------------------------------------------------------------
## lib.size <- apply(data.filter, 1, sum) # determine size of each library
## 
## maximum.lib.size <- 15000
## data.filter <- data.filter[-which(lib.size > maximum.lib.size),] # remove samples which exceed max library size


## ---- fig.cap = "FIGURE 4: Samples of Global Pattern OTU data projected onto components after a CLR transformation."----
pca.result <- pca(data.filter, logratio = 'CLR') # undergo PCA after CLR transformation

plotIndiv(pca.result, group = meta.data$SampleType, title = 'Global Patterns, PCA Comps 1&2') # plot samples


## ---- eval = FALSE------------------------------------------------------------------------------------------
## library(metagenomeSeq)
## 
## data.metagenomeSeq = newMRexperiment(t(data.filter),
##                       featureData=NULL, libSize=NULL, normFactors=NULL) # using filtered data
## p = cumNormStat(data.metagenomeSeq) # default is 0.5
## data.cumnorm = cumNorm(data.metagenomeSeq, p=p)
## 
## data.CSS = t(MRcounts(data.cumnorm, norm=TRUE, log=TRUE))
## dim(data.CSS)  # make sure the data are in a correct format: number of samples in rows

